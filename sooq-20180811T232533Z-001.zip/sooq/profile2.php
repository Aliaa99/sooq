  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideforms.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
            
<!--prfile detals-->
            
        <div class="profiledetals">
              <div class="row">
                 <div class="col-lg-9 col-md-8">
                   <div class="row">
                       <div class="col-xs-3">
                           <img src="images/im.png">
                       </div>
                       <div class="col-xs-9">
                           <h5>اسم العضو : <span>hany_eee</span></h5>
                           <h6>رقم العضوية : <span>1905</span></h6>
                       </div>
                     </div>
                  </div>
                 <div class="col-lg-3 col-md-4">
                    <button class="btn firstbutt">تواصل معى</button>
                  </div>
                </div>
         </div>
            <div class="result">
                
        <!--resulthead-->
                
                <div class="resulthead">
                  <h3>أعلاناتى</h3>
                </div>
        <!--resultdetails-->
                <div class="details">
                    <a href="#">
                        <h5>سيارة بجوى504 بحالة حديثة </h5>
                        <ul>
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i>دول أخرى</li>
                            <li><i class="fa fa-user" aria-hidden="true"></i>nizamalali</li>
                            <li><i class="fa fa-clock-o" aria-hidden="true"></i>قبل 4ساعات</li>
                            <li><i class="fa fa-eye" aria-hidden="true"></i>4 مشاهدات</li>
                        </ul>
                      </a>
                </div>
        <!--resultdetails-->           
                <div class="details">
                    <a href="#">
                        <h5>سيارة بجوى504 بحالة حديثة </h5>
                        <ul>
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i>دول أخرى</li>
                            <li><i class="fa fa-user" aria-hidden="true"></i>nizamalali</li>
                            <li><i class="fa fa-clock-o" aria-hidden="true"></i>قبل 4ساعات</li>
                            <li><i class="fa fa-eye" aria-hidden="true"></i>4 مشاهدات</li>
                        </ul>
                      </a>
                </div>
        <!--resultdetails-->           
                <div class="details">
                    <a href="#">
                        <h5>سيارة بجوى504 بحالة حديثة </h5>
                        <ul>
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i>دول أخرى</li>
                            <li><i class="fa fa-user" aria-hidden="true"></i>nizamalali</li>
                            <li><i class="fa fa-clock-o" aria-hidden="true"></i>قبل 4ساعات</li>
                            <li><i class="fa fa-eye" aria-hidden="true"></i>4 مشاهدات</li>
                        </ul>
                      </a>
                </div>
                
            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>



  <?php
include 'footer.php';
?>
