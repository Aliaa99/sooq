  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideprofile.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
            <div class="about">
                <h3>رسائلى</h3>
                    <div class="table1">
                      <table class="table">
                        <thead>
                          <tr>
                            <th>قبل 4 ساعات</th>
                            <th>أسم المرسل</th>
                            <th>الرسالة</th>
                            <th>تاريخ</th>
                            <th>الحالة</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>1</td>
                            <td>هانى السيد</td>
                            <td>رائع جدا</td>
                            <td>قبل 36دقيققه</td>
                            <td>مقروءه</td>
                          </tr>
                          <tr>
                            <td>1</td>
                            <td>هانى السيد</td>
                            <td>رائع جدا</td>
                            <td>قبل 36دقيققه</td>
                            <td>مقروءه</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                <div class="form-controller">
                     <button class="btn delet">حذف الجميع</button>
                </div>
            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>


  <?php
include 'footer.php';
?>
