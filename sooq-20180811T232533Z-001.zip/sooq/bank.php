  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideforms.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
            <div class="bank">
               <div class="bankhead">
    <!--bank head-->
                  <h3>الحسابات البنكية</h3>
                </div>
                <div class="row">
<!--repeat link-->
            <div  class="bankdetais">
                  <a href="#">
                    <div class="col-xs-3 center">
                        <img src="images/bank1.png">
                    </div>
                    <div class="col-xs-9">
                        <h4>البنك الاهلى</h4>
                        <ul>
                          <li>اسم المستفيد: <span>حساب مؤسسة آزر للدعاية والإعلان</span></li>
                          <li>رقم الحساب: <span>58965258896563547</span> </li>
                          <li>ايبان: <span>SA6510000008967792000106</span></li>
                        </ul>
                    </div>
                    </a>
                </div>
                    
<!--repeat link-->
                    
            <div  class="bankdetais">
                  <a href="#">
                    <div class="col-xs-3 center">
                        <img src="images/bank2.png">
                    </div>
                    <div class="col-xs-9">
                        <h4>بنك الراجحى</h4>
                        <ul>
                          <li>اسم المستفيد: <span>حساب مؤسسة آزر للدعاية والإعلان</span></li>
                          <li>رقم الحساب: <span>58965258896563547</span> </li>
                          <li>ايبان: <span>SA6510000008967792000106</span></li>
                        </ul>
                    </div>
                    </a>
                </div>
                </div>
            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>

  <?php
include 'footer.php';
?>
