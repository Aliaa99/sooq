  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideforms.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
            <!--main div -->
            <div class="result">
                <div class="resulthead">
                  <h3>عقارات فلل-قصور</h3>
                    <select>
                      <option disabled selected>كل المدن</option>
                      <option>1</option>
                      <option>1</option>
                    </select>
                </div>
            <!-- repeated div -->
                <div class="details">
                    <a href="#">
                        <h5>دبلكسات فاخرة للبيع بالنقدوالتقسيط… </h5>
                        <ul>
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i>دول أخرى</li>
                            <li><i class="fa fa-user" aria-hidden="true"></i>nizamalali</li>
                            <li><i class="fa fa-clock-o" aria-hidden="true"></i>قبل 4ساعات</li>
                            <li><i class="fa fa-eye" aria-hidden="true"></i>4 مشاهدات</li>
                        </ul>
                      </a>
                </div>
            <!-- repeated div -->
                <div class="details">
                    <a href="#">
                        <h5>فيلا درج صالة بشقتين بحي العوالي</h5>
                        <ul>
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i>دول أخرى</li>
                            <li><i class="fa fa-user" aria-hidden="true"></i>nizamalali</li>
                            <li><i class="fa fa-clock-o" aria-hidden="true"></i>قبل 4ساعات</li>
                            <li><i class="fa fa-eye" aria-hidden="true"></i>4 مشاهدات</li>
                        </ul>
                      </a>
                </div>
                
                
                
            </div>
        </div>
<!--main-->


<!--left side-->
  <?php
include 'leftside.php';
?>

<!--media-->
  <?php
include 'media3.php';
?>


  <?php
include 'footer.php';
?>
