  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideprofile.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
            <div class="about">
               <div class="bankhead">
                   <!--bank head-->
                   <h3>تواصل مع الاعضاء</h3>
                </div>   
            <!--search input-->
                <div class="search">
                  <input type="search" placeholder="اسم العضو">
                </div>
                    <div class="table1">
                      <table class="table">
                        <thead>
                          <tr>
                            <th>رقم العضوية</th>
                            <th>اسم العضو</th>
                            <th>صورة العضو</th>
                            <th>الحالة</th>
                            <th>محادثة العضو</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>1</td>
                            <td>هانى السيد</td>
                            <td><img src="images/im.png"></td>
                            <td>متواجد</td>
                            <td><a href="#">محادثة</a></td>
                          </tr>
                          <tr>
                            <td>1</td>
                            <td>هانى السيد</td>
                            <td><img src="images/im.png"></td>
                            <td>متواجد</td>
                            <td><a href="#">محادثة</a></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>

  <?php
include 'footer.php';
?>
