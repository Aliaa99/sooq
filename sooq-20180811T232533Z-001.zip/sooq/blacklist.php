  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideforms.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
            <div class="bank">
               <div class="bankhead">
    <!--bank head-->
                  <h3>القائمة السوداء</h3>
                </div>
<!--blacklist-->
            <div  class="bankdetais impo">
                <p>القائمة السوداء هي قائمة بإرقام حسابات وأرقام جوالات من يقومون بإساءة إستخدام الموقع لأغراض ممنوعه مثل الغش أو الأحتيال
                أو مخالفة قوانين الموقع
                </p>
<!--blacklist form-->
                <form>
                    <input type="text" placeholder="ادحل رقم الحساب او رقم الجوال هنا">
                    <div class="form-controller">
                     <button class="btn firstbutt">فحص الآن</button>
                </div>
                </form>
            </div>
            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>

  <?php
include 'footer.php';
?>
