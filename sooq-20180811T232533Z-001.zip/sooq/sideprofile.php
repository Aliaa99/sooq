<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-sm-6">
        <aside>
<!--بحث عن سلعة-->
            <form>
                <h5><i class="fa fa-search" aria-hidden="true"></i>بحث</h5>
               <div class="form-controller">
                   <input type="text" placeholder="بحث عن سلعة">
               </div>
                <div class="form-controller">
                     <button class="btn firstbutt">أبحث الآن</button>
                    <button class="btn secbutt">بحث متقدم</button>
                </div>
            </form>
<!--ملف شخصى-->
            <div class="personaldata">
              <h3>ملف شخصى <span>hane-eee</span></h3>
                <ul>
                    <li><a href="#">بياناتى</a></li>
                    <li><a href="#">رسائلى</a></li>
                    <li><a href="#">مفضلتى</a></li>
                    <li><a href="#">اضافة اعلان</a></li>
                    <li><a href="#">تعديل حساب</a></li>
                    <li><a href="#">تعديل كلمة المرور</a></li>
                    <li><a href="#">تسجيل خروج</a></li>
                </ul>
                    <button class="btn secbutt">تواصل مع الاعضاء</button>
            </div>
<!--3mola-->
            <form>
                <h5><i class="fa fa-money" aria-hidden="true"></i>حساب العمولة
                </h5>
               <div class="form-controller">
                   <input type="text" class="width-custtom">
                   <lable>العمولة هى<span>0</span>ريال </lable>
               </div>
            </form>
            </aside>
        </div>
        
        










