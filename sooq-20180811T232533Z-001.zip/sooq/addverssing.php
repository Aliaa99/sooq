  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideforms.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
            <div class="addvers">
               <ul>
                  <li><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i>المنطقة:السعودية,الرياض</a></li>
                  <li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i>رقم الجوال:2157876</a></li>
                  <li><a href="#"><i class="fa fa-user" aria-hidden="true"></i>المعلن:نزان</a></li>
                  <li><a href="#"><i class="fa fa-whatsapp" aria-hidden="true"></i>راسل المعلن:+65478895458588</a></li>
                  <li><a href="#"><i class="fa fa-refresh" aria-hidden="true"></i>اخر تحديث للاعلان: قبل 6 ساعات</a></li>
                  <li><a href="#"><i class="fa fa-hashtag" aria-hidden="true"></i>رقم الاعلان:1257</a></li>
                  <li><a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i>قبل 4 ساعات</a></li>
                </ul>
                    <!--details-->
                <div class="addv">
                  <h3>تأمين قطع غيار معدات شيولات كتربلر فوركاو</h3>
                  <p>السلام عليكم ورحمة الله وبركاتة 
                    تامين جميع انواع قطع الغيار المستعملة و الجديدة للشيولات فوركاوا ومتسوبيشي كتربلر .. الخ ويوجد توصيل الى جميع انحاء المملكة عن طريق شركات الشحن. لطلب القطعة رقم القطعة أو صورة للقطعة إن وجدت . والموديل على وتس أب
                    (الرجاء الطلب للجادين فقط )
                    الاتصال على الجوال 
                    شعارنا الصدق والامانه و السرعة
                    ونسعي لرضائكم دائما 
                    اخوكم ابو عبدو
                    وشكرا
                    </p>

                    <!--images of product-->
                    <div class="show-img">
                        <ul>
                           <li> 
                               <a data-fancybox="gallery" href="images/car.png" class="various fancyboxvarious fancybox">
                               <img src="images/car.png">
                               </a>
                            </li>
                             <li>  
                                 <a data-fancybox="gallery" href="images/car2.png"class="various fancybox">
                                   <img src="images/car2.png">
                                 </a>
                            </li>
                             <li>  
                                 <a data-fancybox="gallery" href="images/car2.png"class="various fancybox">
                                   <img src="images/car2.png">
                                 </a>
                            </li>
                             <li>  
                                 <a data-fancybox="gallery" href="images/car2.png"class="various fancybox">
                                   <img src="images/car2.png">
                                 </a>
                            </li>
                             <li>  
                                 <a data-fancybox="gallery" href="images/car2.png"class="various fancybox">
                                   <img src="images/car2.png">
                                 </a>
                            </li>
                        </ul>
                    </div>
                    <!--attention -->
                    <div class="attention">
                        <h6>إحذر من التعامل غير المباشر . </h6>
                         <h6>إستخدم القائمة السوداء قبل اى عملية تحويل</h6>
                    </div>
                    <!--comments div profile-->
                    <div class="comment">
                       <h3>التعليقات</h3>
                        <div class="comm">
                            <div class="profile">
                            <div class="row">
                                <div class="col-xs-2 center">
                                   <img src="images/im.png">
                                </div>
                                <div class="col-xs-9">
                                    <h4>محمد على</h4>
                                    <span>30سنة</span>
                                </div>
                            </div>
                            </div>
                            <div class="wordscomment">
                               <p>موضوع جميل يا صديقى </p>
                            </div>
                        </div>
                    </div>
                <!--comments form-->
                    <form>
                        <textarea placeholder="أضف تعليقك" rows="8"></textarea>
                        <button>أضف تعليقك</button>
                    </form>
                </div>
            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>
  <?php
include 'media3.php';
?>



  <?php
include 'footer.php';
?>
