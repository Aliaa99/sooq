  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideforms.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
            <div class="contact">
               <div class="social">
            <!--عنوان اساسي-->
                   <h3>تواصل معنا</h3>
                  <ul>
                     <li><a href="#"><i class="fa fa-facebook-square face" aria-hidden="true"></i>فيس بوك</a></li>
                      <li><a href="#"><i class="fa fa-twitter-square tweeter" aria-hidden="true"></i>تويتر</a></li>
                      <li><a href="#"><i class="fa fa-google-plus-square google" aria-hidden="true"></i>جوجل+</a></li>
                     <li><a href="#"><i class="fa fa-instagram insta" aria-hidden="true"></i>أنستقرام</a></li>
                     <li><a href="#"><i class="fa fa-youtube-square yout" aria-hidden="true"></i>يوتيوب</a></li>
                     <li><a href="#"><i class="fa fa-whatsapp whats" aria-hidden="true"></i>125257899133</a></li>
                   </ul>
                   <h5>نسعد بتواصلكم واقتراحاتكم واستقبال الشكاوى من خلال تعبئة الخانات الاتية</h5>
            <!--فورمة-->
                   <form>
                       <input type="text" placeholder="الاسم">
                       <input type="email" placeholder="الايميل">
                       <input type="text" placeholder="الجوال">
                       <textarea placeholder="الرسالة" rows="8"></textarea>
                       <button>أرسال</button>
                   </form>
                </div>

            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>

  <?php
include 'footer.php';
?>
