<!DOCTYPE html>
<html lang="en">
<head>
  <title>web-page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap-rtl.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/animate.min.css">
  <link rel="stylesheet" href="css/lightbox.css">
  <link rel="stylesheet" href="css/aos.css">
<!--  <link rel="stylesheet" href="css/demo.css">-->
  <link rel="stylesheet" href="css/component.css">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="shortcut icon" href="images/logo.png">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/stylesheet.css">

</head>
<header>
    <div class="headerr">
        <div class="container">
           <div class="row">
              <div class="col-sm-3">
                 <img src="images/logo.png">
               </div>
              <div class="col-sm-9">
                 <div class="time">
                    <i class="fa fa-clock-o" aria-hidden="true"></i>
                    <span>9:22am</span>
                  </div>
                 <div class="date">
                     <i class="fa fa-calendar" aria-hidden="true"></i>
                     <span> الخميس 2018/4/19م - 1439/8/3هــ</span>
                  </div>
                 <div class="nav">
                     <ul>
                       <li><a href="index.php">رئيسية</a></li>
                       <li><a href="about.php">من نحن</a></li>
                       <li><a href="site-policy.php">سياسة الموقع</a></li>
                       <li><a href="">موقعنا</a></li>
                       <li><a href="media-service.php">خدمة اعلانية</a></li>
                       <li><a href="commission.php">حساب العمولة</a></li>
                       <li><a href="contactus.php">تواصل معنا</a></li>
                     </ul>
                  </div>
               </div>
            </div>
        </div>
    </div>
</header>
<div class="sidemen" >
      <div class="side-nav">
        <div class="main">
          <a href="#side-list" class="op"><i class="fa fa-bars" aria-hidden="true"></i></a>
          <a href="#"><img src="images/logo.png"></a>
        </div>
        <div class="menu2 animated fadeInRight" id="side-list">
          <a href="#side-list" class="clo"><i class="fa fa-times" aria-hidden="true"></i></a>
             <ul>
               <li><a href="index.php">رئيسية</a></li>
               <li><a href="about.php">من نحن</a></li>
               <li><a href="site-policy.php">سياسة الموقع</a></li>
               <li><a href="">موقعنا</a></li>
               <li><a href="media-service.php">خدمة اعلانية</a></li>
               <li><a href="commission.php">حساب العمولة</a></li>
               <li><a href="contactus.php">تواصل معنا</a></li>
             </ul>
        </div>
    </div>
         

    </div>