<!--##################### footer ##################-->
<footer>
    <div class="footerlinks">
      <div class="container">
          <div class="row">
              <div class="col-sm-4">
              <ul>
                <li><a href="#">حساب العمولة</a></li>
                <li><a href="#">الاعلانات المميزة</a></li>
                <li><a href="#">الأحكام والشروط</a></li>
              </ul>
            </div>
              <div class="col-sm-3 col-sm-offset-1">
              <ul>
                <li><a href="#">الحسابات البنكية</a></li>
                <li><a href="#">تواصل معنا</a></li>
                <li><a href="#">القائمة السوداء</a></li>
              </ul>
            </div>
              <div class="col-sm-2 col-sm-offset-2">
              <ul>
                <li><a href="#">من نحن</a></li>
                <li><a href="#">سياسة الموقع</a></li>
                <li><a href="#">موقعنا</a></li>
                <li><a href="#">خدمة إعلانية</a></li>
              </ul>
            </div>
          </div>
          <div class="finish">
            <div><i class="fa fa-whatsapp green" aria-hidden="true"></i><span>0254788/7888</span></div>
            <div><i class="fa fa-envelope" aria-hidden="true"></i><a href="#">aliaa@bb4it.com</a></div>
            <div><p>© 2018 جميع الحقوق محفوظة لموقع .<a href="#">سوق البلد</a></p></div>
          </div>
        </div>
    </div>
</footer>


    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.carousel.js"></script>
    <script src="js/lightbox.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.nicescroll.iframehelper.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/jquery.custom-file-input.js"></script>
    <script src="js/custom-file-input.js"></script>
    <script type="text/javascript" src="js/main.js"></script>

</body>
</html>