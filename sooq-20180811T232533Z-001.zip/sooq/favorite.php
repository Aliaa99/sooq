  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideprofile.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
            <div class="result">
            <!--resulthead-->
                <div class="resulthead">
                  <h3>مفضلتى</h3>
                </div>
        <!--resultdetails-->
                <div class="details">
                    <a href="#">
                        <h5>سيارة بجوى504 بحالة حديثة </h5>
                        <ul class="listdet">
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i>دول أخرى</li>
                            <li><i class="fa fa-user" aria-hidden="true"></i>nizamalali</li>
                            <li><i class="fa fa-clock-o" aria-hidden="true"></i>قبل 4ساعات</li>
                            <li><i class="fa fa-eye" aria-hidden="true"></i>4 مشاهدات</li>
                            <li><i class="fa fa-heart" aria-hidden="true"></i>إلغاء من مفضلتى </li>
                        </ul>
                        <div class="immage">
                           <img src="images/im.png">
                        </div>
                      </a>
                </div>
                
            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>



  <?php
include 'footer.php';
?>
