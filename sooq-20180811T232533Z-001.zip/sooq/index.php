  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideforms.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
            <div class="links-media">
              <a href="addaddress.php" class="btn firstbutt">أضف إعلانات</a>
              <a href="3qar.php" class="btn secbutt">مشاهدة إعلانات</a>
            </div>
            <div class="row">
              <div class="col-md-4 col-sm-6">
                  <div class="show-product">
                      <a href="3qar-result.php" class="kinds" data-aos="zoom-in">
                       <img src="images/img2.png">
                      <span>سيارات</span>
                     </a>
                  </div>
              </div>
              <div class="col-md-4 col-sm-6">
                  <div class="show-product">
                 <a href="3qar-result.php" class="kinds" data-aos="zoom-in">
                    <img src="images/img3.png">
                    <span>عقارات</span>
                 </a>
                </div>
              </div>
              <div class="col-md-4 col-sm-6">
                  <div class="show-product">
                 <a href="#" class="kinds" data-aos="zoom-in">
                    <img src="images/img4.png">
                    <span>إلكترونيات</span>
                 </a>
                  </div>
              </div>
              <div class="col-md-4 col-sm-6">
                  <div class="show-product">
                 <a href="3qar-result.php" class="kinds" data-aos="zoom-in">
                    <img src="images/img5.png">
                    <span>أساس ومفروشات</span>
                 </a>
                </div>
              </div>
              <div class="col-md-4 col-sm-6">
                  <div class="show-product">
                 <a href="3qar-result.php" class="kinds" data-aos="zoom-in">
                    <img src="images/img5.png">
                    <span>أساس ومفروشات</span>
                 </a>
                </div>
              </div>
              <div class="col-md-4 col-sm-6">
                  <div class="show-product">
                 <a href="3qar-result.php" class="kinds" data-aos="zoom-in">
                    <img src="images/img5.png">
                    <span>أساس ومفروشات</span>
                 </a>
                </div>
              </div>
              <div class="col-md-4 col-sm-6">
                  <div class="show-product">
                 <a href="3qar-result.php" class="kinds" data-aos="zoom-in">
                    <img src="images/img5.png">
                    <span>أساس ومفروشات</span>
                 </a>
                </div>
              </div>
              <div class="col-md-4 col-sm-6">
                  <div class="show-product">
                 <a href="3qar-result.php" class="kinds" data-aos="zoom-in">
                    <img src="images/img5.png">
                    <span>أساس ومفروشات</span>
                 </a>
                </div>
              </div>
            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>


  <?php
include 'media2.php';
?>







  <?php
include 'footer.php';
?>
