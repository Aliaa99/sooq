  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideforms.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
            <div class="contact">
               <div class="social">
                   <h3>البحث المتقدم</h3>
                   <form>
                      <div class="select-div">
                          <select>
                               <option disabled selected>أختيار القسم الرئيسي</option>
                               <option>1</option>
                               <option>2</option>
                               <option>3</option>
                           </select>
                       </div>
                      <div class="select-div">
                          <select>
                               <option disabled selected>أختيار القسم الفرعى</option>
                               <option>1</option>
                               <option>2</option>
                               <option>3</option>
                           </select>
                       </div>
                      <div class="select-div">
                          <select>
                               <option disabled selected>أختيار النوع</option>
                               <option>1</option>
                               <option>2</option>
                               <option>3</option>
                           </select>
                       </div>
                      <div class="select-div">
                          <select>
                               <option disabled selected>أختيار الدولة</option>
                               <option>1</option>
                               <option>2</option>
                               <option>3</option>
                           </select>
                       </div>
                      <div class="select-div">
                          <select>
                               <option disabled selected>أختيار المدينة</option>
                               <option>1</option>
                               <option>2</option>
                               <option>3</option>
                           </select>
                       </div>
                        <!--button to search-->
                       <button>بحث الان</button>
                   </form>
                </div>
                     
            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>

        <?php
        include 'media2.php';
        ?>


  <?php
include 'footer.php';
?>
