$('.one').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    rtl:true,
    dots:false,
    autoplay:true,
    autoplayTimeout:5000,
    responsive:{
        0:{
            items:1
        }
    }
})

AOS.init({
  offset: 100,
  duration: 500,
  easing: 'ease-in-quad',
  delay: 0,
});


$('.second').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    rtl:true,
    autoplay:true,
    autoplayTimeout:2000,
    dots:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        },
         1500:{
            items:4
        }
    }
})


    //fancy box
    $('.various').fancybox({
        padding : 10,
        openEffect  : 'fade'
    });
$(document).ready(function(){
        $('.chatlist ul li ,.nav ul li').click(function(){
        $(this).addClass("active").siblings().removeClass("active");
    });
    $('.cahthead').click(function(){
        $('.chatscroll,.chatsend,.chatlist').toggle();
    });
    $('.chatlist ul li a span i').click(function(){
        $(this).parent().parent().parent().remove();
    });
   $(".nicescroll-box").niceScroll(".wrap",{cursorcolor:"#616161",cursorwidth:"8px",background:"rgba(97,97,97,0.5)",cursorborder:"1px solid #afafaf",autohidemode:'leave'});
});

//menu

$(document).ready(function(){
    $('.main .op').click(function(){
        $('.menu2').css({"width":"60%",})
        $('.main').css({"left":"40%",})
        $(this).toggle();
        $('.main span').toggle();

    });
    $('.menu2 .clo').click(function(){
        $(this).parent().css({"width":"0",})
        $('.main').css({"left":"0",})
        $('.main .op').toggle();
        $('.main span').toggle();
    });
        $('.opop').click(function(){
        $('.men').slideToggle();
    });
});
////scroll background color of navbar
//      $(window).scroll(function() {
//       		var scrollVal = $(this).scrollTop();
//        	if ( scrollVal > 150) {
//            	
//            	$('.main').css({'top':'0','opacity':'1'});
//            	$('.menu2').css({'top':'0'});
//        	}
//              else{
//                  
//            	$('.main').css({'top':'40px','opacity':'.7'});
//            	$('.menu2').css({'top':'40px'});
//              }
//        	
//    	});
//            // scroll down 
//
//$('.bott a').click (function(){
//      $('html,body').animate({         scrollTop:$("#toppage").offset().top},1000);
//   });
//
