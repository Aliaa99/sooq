  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideforms.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
            <div class="about">
                <h3>تسجيل عضوية جديدة</h3>
                <form>
               <div class="form-controller">
                   <input type="text" placeholder="أسم المستخدم">
               </div>
               <div class="form-controller">
                   <input type="email" placeholder="الايميل">
               </div>
               <div class="form-controller widthsp">
                   <div class="row">
                <div class="col-xs-7 col-lg-9 col-md-8 col-sm-9 padl">
                      <input type="text" placeholder="رقم الجوال" class="halfwidth">
                </div>
                <div class="col-xs-5 col-lg-3 col-md-4 col-sm-3 padd">
                    <div class="sel">
                        <select class="select-contry">
                            <option>966+ السعودية</option>
                            <option>966+ السعودية</option>
                            <option>966+ السعودية</option>
                            <option>966+ السعودية</option>
                       </select>
                    </div>
                </div>
                </div>
              </div>
               <div class="form-controller">
                   <input type="password" placeholder="كلمة المرور">
               </div>
               <div class="form-controller">
                   <input type="password" placeholder="تأكيد كلمة المرور">
               </div>
                <div class="form-controller">
                     <button class="btn firstbutt">تسجيل الان</button>
                </div>
                </form>
            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>

  <?php
include 'footer.php';
?>
