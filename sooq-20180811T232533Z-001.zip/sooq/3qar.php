  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideforms.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
          <div class="aqaardiv">
            <div class="row">
            <!--3qarat head-->
                <h3>عقارات</h3>
            <!-- repeated div -->
                  <div class="col-lg-4 col-md-6">
                    <div class="building-img">
                        <a href="#">
                            <img src="images/f1.png">
                            <span>فلل-قصور</span>
                        </a>
                   </div>
                 </div>
            <!-- repeated div -->
                  <div class="col-lg-4 col-md-6">
                    <div class="building-img">
                        <a href="#">
                            <img src="images/f2.png">
                            <span>عمائر</span>
                        </a>
                   </div>
                 </div>
            <!-- repeated div -->
                  <div class="col-lg-4 col-md-6">
                    <div class="building-img">
                        <a href="#">
                            <img src="images/f3.png">
                            <span>شقق</span>
                        </a>
                   </div>
                 </div>
            <!-- repeated div -->
                  <div class="col-lg-4 col-md-6">
                    <div class="building-img">
                        <a href="#">
                            <img src="images/f4.png">
                            <span>محلات تجارية</span>
                        </a>
                   </div>
                 </div>
                  <div class="col-lg-4 col-md-6">
                    <div class="building-img">
                        <a href="#">
                            <img src="images/f1.png">
                            <span>فلل-قصور</span>
                        </a>
                   </div>
                 </div>
            <!-- repeated div -->
                  <div class="col-lg-4 col-md-6">
                    <div class="building-img">
                        <a href="#">
                            <img src="images/f1.png">
                            <span>فلل-قصور</span>
                        </a>
                   </div>
                 </div>
              </div>
            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>
  <?php
include 'media3.php';
?>



  <?php
include 'footer.php';
?>
