  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideforms.php';
?>

<!--main-->
        <div class="col-md-6 col-sm-12">
            <div class="result">
            <!--resulthead-->
                <div class="resulthead">
                  <h3>نتائج بحث عن (<span>سيارات</span>)</h3>
                    <select>
                      <option disabled selected>كل المدن</option>
                      <option>1</option>
                      <option>1</option>
                    </select>
                </div>
        <!--resultdetails-->
                <div class="details">
                    <a href="#">
                        <h5>سيارة بجوى504 بحالة حديثة </h5>
                        <ul>
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i>دول أخرى</li>
                            <li><i class="fa fa-user" aria-hidden="true"></i>nizamalali</li>
                            <li><i class="fa fa-clock-o" aria-hidden="true"></i>قبل 4ساعات</li>
                            <li><i class="fa fa-eye" aria-hidden="true"></i>4 مشاهدات</li>
                        </ul>
                      </a>
                </div>
        <!--resultdetails-->           
                <div class="details">
                    <a href="#">
                        <h5>سيارة بجوى504 بحالة حديثة </h5>
                        <ul>
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i>دول أخرى</li>
                            <li><i class="fa fa-user" aria-hidden="true"></i>nizamalali</li>
                            <li><i class="fa fa-clock-o" aria-hidden="true"></i>قبل 4ساعات</li>
                            <li><i class="fa fa-eye" aria-hidden="true"></i>4 مشاهدات</li>
                        </ul>
                      </a>
                </div>
        <!--resultdetails-->           
                <div class="details">
                    <a href="#">
                        <h5>سيارة بجوى504 بحالة حديثة </h5>
                        <ul>
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i>دول أخرى</li>
                            <li><i class="fa fa-user" aria-hidden="true"></i>nizamalali</li>
                            <li><i class="fa fa-clock-o" aria-hidden="true"></i>قبل 4ساعات</li>
                            <li><i class="fa fa-eye" aria-hidden="true"></i>4 مشاهدات</li>
                        </ul>
                      </a>
                </div>
                
            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>



  <?php
include 'footer.php';
?>
