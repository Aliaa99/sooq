  <?php
include 'header.php';
?>
  <?php
include 'nav.php';
?>
  <?php
include 'sideprofile.php';
?>

<!--main-->
        <div class="col-sm-6">
            <div class="about">
               <div class="bankhead">
                   <!--bank head-->
                   <h3>تغيير كلمة المرور</h3>
                </div>   
                <form>
               <div class="form-controller">
                   <input type="password" placeholder="كلمة المرور القديمة">
               </div>
               <div class="form-controller">
                   <input type="password" placeholder="كلمة المرور الجديده">
               </div>
               <div class="form-controller">
                   <input type="password" placeholder="تأكيد كلة المرور">
               </div>
                <div class="form-controller">
                     <button class="btn firstbutt buttonoptions">تغيير الان</button>
                </div>
                </form>
            </div>
        </div>
<!--main-->

  <?php
include 'leftside.php';
?>

  <?php
include 'footer.php';
?>
