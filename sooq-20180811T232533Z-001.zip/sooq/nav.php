 <body>
   
    <div class="imgs">
       <ul>
         <li><span>بيع</span></li>
         <li><span>شراء</span></li>
         <li><span>جديد</span></li>
         <li><span>مستعمل</span></li>
         <li><img src="images/img1.png"></li>
       </ul>
     </div> 
