    <div class="media2">
        <div class="container">
            <h4><i class="fa fa-bookmark" aria-hidden="true"></i>إعلانات ذات صلة</h4>
                    <!--owl carousel-->
            <div class="owl-carousel owl-theme second">
                <div class="item">
                    <div class="media med">
                        <div>
                        <a href="#">
                          <img src="images/e1.png">
                          <h4>عرض مميز على لابتوب من hp ب 1500فقط</h4>
                        </a>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="media med">
                        <div>
                        <a href="#">
                          <img src="images/e1.png">
                          <h4>عرض مميز على لابتوب من hp ب 1500فقط</h4>
                        </a>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="media med">
                        <div>
                        <a href="#">
                          <img src="images/e1.png">
                          <h4>عرض مميز على لابتوب من hp ب 1500فقط</h4>
                        </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


