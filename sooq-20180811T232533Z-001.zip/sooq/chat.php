<div class="chat">
   <div class="chatbody">
<!--head name-->
       <div class="cahthead">
           <a href="#"> ahmed</a>
       </div>
<!-- chat-->
             <div class="chatscroll">
                 <div class="him">
                    <p> كيفك
                     </p>
                   </div>
                 <div class="me">
                     اهلين
                   </div>
               </div>
<!--send-->
       <div class="chatsend">
         <input type="text" placeholder="اكتب رسالتك">
         <button><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
       </div>
   </div>
<!--chat list-->
   <div class="chatlist">
       <ul>
         <li class="active">
            <a href="#">ahmed <span><i class="fa fa-times" aria-hidden="true"></i></span></a>
         </li>
         <li>
            <a href="#">ahmed <span><i class="fa fa-times" aria-hidden="true"></i></span></a>
         </li>
       </ul>
   </div>
</div>