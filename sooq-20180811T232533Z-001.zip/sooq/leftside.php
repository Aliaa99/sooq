        <div class="col-md-3 col-sm-6">
        <aside>
             <div class="hed">
                 <h5><i class="fa fa-credit-card" aria-hidden="true"></i>أحدث الإعلانات
                 </h5>
              </div>
               <div class="owl-carousel owl-theme one">
                <div class="item">
                    <div class="media">
                        <div>
                            <a href="#">
                              <img src="images/e1.png">
                              <h4>عرض مميز على لابتوب من hp ب 1500فقط</h4>
                            </a>
                        </div>
                    </div>
                    <div class="media">
                        <div>
                            <a href="#">
                              <img src="images/e2.png">
                              <h4>عرض مميز على لابتوب من hp ب 1500فقط</h4>
                            </a>
                        </div>
                    </div>
                    <div class="media">
                        <div>
                        <a href="#">
                          <img src="images/e1.png">
                          <h4>عرض مميز على لابتوب من hp ب 1500فقط</h4>
                        </a>
                        </div>
                    </div>
                    <div class="media">
                        <div>
                        <a href="#">
                          <img src="images/e2.png">
                          <h4>عرض مميز على لابتوب من hp ب 1500فقط</h4>
                        </a>
                        </div>
                    </div>
                    <div class="media">
                        <div>
                        <a href="#">
                          <img src="images/e1.png">
                          <h4>عرض مميز على لابتوب من hp ب 1500فقط</h4>
                        </a>
                        </div>
                    </div>
                </div>
            </div>
            </aside>
       </div>
        
        
   </div>    
</div>










