<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-sm-6">
        <aside>
<!--بحث عن سلعة-->
            <form>
                <h5><i class="fa fa-search" aria-hidden="true"></i>بحث</h5>
               <div class="form-controller">
                   <input type="text" placeholder="بحث عن سلعة">
               </div>
                <div class="form-controller">
                     <button class="btn firstbutt">أبحث الآن</button>
                    <button class="btn secbutt">بحث متقدم</button>
                </div>
            </form>
<!--تسجيل دخول-->
            <form>
                <h5 class="marr"><i class="fa fa-user" aria-hidden="true"></i>تسجيل دخول</h5>
               <div class="form-controller">
                   <input type="text" placeholder="أسم المستخدم">
               </div>
               <div class="form-controller">
                   <input type="password" placeholder="كلمة السر">
               </div>
                <div class="form-controller">
                    <a href="#">هل نسيت كلمة السر؟</a>
                </div>
                <div class="form-controller">
                     <button class="btn firstbutt">دخول</button>
                    <button class="btn secbutt">تسجيل جديد</button>
                </div>
            </form>
<!--3mola-->
            <form>
                <h5><i class="fa fa-money" aria-hidden="true"></i>حساب العمولة
                </h5>
               <div class="form-controller">
                   <input type="text" class="width-custtom">
                   <lable>العمولة هى<span>0</span>ريال </lable>
               </div>
            </form>
            </aside>
        </div>
        
        










